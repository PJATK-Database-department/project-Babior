namespace MarketWatch.Shared.Responses
{
    public class CompanyResponse
    {
        public string Ticker { get; set; }
        public string Name { get; set; }
        public string PrimaryExchange { get; set; }
    }
}