using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MarketWatch.Client.Services.Contracts;
using MarketWatch.Shared.Dtos;
using Microsoft.AspNetCore.Components;

namespace MarketWatch.Client.Pages.Dashboard
{
    public class BlogPostsBase : ComponentBase
    {
        [Inject] public INewsService NewsService { get; set; }
        [Parameter] public string TickerName { get; set; }

        protected List<NewsDto> News { get; set; } = new();
        
        private async Task LoadNewsData()
        {
            var response = await NewsService.GetNewsByTicker(TickerName);
            News = response.ToList();
            StateHasChanged();
        }
        
        protected override async Task OnInitializedAsync()
        {
            await LoadNewsData();
        }
    }
}